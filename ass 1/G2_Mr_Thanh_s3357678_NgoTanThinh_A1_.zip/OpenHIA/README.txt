id: s3357678
name: Ngo Tan Thinh

three C# features:
- Properties : in Model class - Doctor, Hospital, Patient, Visit
- Iterator: in most CRUD service classes
- Collection: in Database class

Note:
- I assume name can't have number for human but maybe for hospital ( so no numberic checking for hospital's name)
- I assume maximum user's input is 15 character long
- I assume ICD code contains both number and letters
- Visit display doctor and patient id but name for hospital (because nearly no hospital has the same name - I think)