﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenHIA.Program
{
    class MainClass
    {
        public static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }
    }
}
