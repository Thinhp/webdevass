﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OpenHIA.Model
{
    public class Database
    {
        public static List<Doctor> DoctorList = new List<Doctor>();
        public static List<Patient> PatientList = new List<Patient>();
        public static List<Hospital> HospitalList = new List<Hospital>();
        public static List<Visit> VisitList = new List<Visit>();
    }
}
